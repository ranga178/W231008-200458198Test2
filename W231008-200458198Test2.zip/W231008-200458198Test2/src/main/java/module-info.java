module com.example.w231008200458198test2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.w231008200458198test2 to javafx.fxml;
    exports com.example.w231008200458198test2;
}